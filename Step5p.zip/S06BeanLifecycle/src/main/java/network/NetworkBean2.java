package network;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class NetworkBean2 extends Network implements InitializingBean, DisposableBean{
	
	// Network network = new Network();
	
	public void open() {
		System.out.println("NetworkBean open()");
		super.connect("http://ez.edu");
	}

	public void close() {
		System.out.println("NetworkBean close()");
		super.disconnect();
	}
	
	@Override
	public int send(String msg) {
		System.out.println("NetworkBean send()");
		int len = super.send(msg);
		System.out.printf("msg len(%d) succeed.\n", len);
		return len;
	}

	@Override
	public void destroy() throws Exception {
		close();
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		open();
	}
}
