package config;

public class MysqlInfo {
	public static String driver = "com.mysql.jdbc.Driver";
	public static String url = "jdbc:mysql://localhost/hellodb?characterEncoding=utf8";
	public static String username = "HELLOUSER";
	public static String password = "HELLOUSER";
}
