package dbquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import spring.dao.Member;

public class DbQueryTR2 {
	
	private DataSource dataSource;

	public DbQueryTR2(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public int count() {
		Connection conn = null;
		
		
		try {
			conn = dataSource.getConnection();
			
			System.out.println("[DbQuery] autocommit=" + conn.getAutoCommit());
			
			try (Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery("select count(*) from MEMBER")) {
				rs.next();
				return rs.getInt(1);
			}
		} 
		catch (SQLException e) {
			throw new RuntimeException(e);
		} 
		finally {
			if (conn != null) {
				try {
					conn.close();
				} 
				catch (SQLException e) {
				}
			}
		}
	}
	
	public void transactionOne(Member member) {
		Connection conn = null;
		
		try {
			System.out.println("[트랜잭션] 시작");
			
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			System.out.println("[DbQuery] autocommit=" + conn.getAutoCommit());
			
			System.out.println("[트랜잭션] 입력");
			insert(conn, member);
			System.out.println("[트랜잭션] 수정");
			update(conn, member);
			System.out.println("[트랜잭션] 삭제");
			delete(conn, member);
			
		} 
		catch (SQLException e) {
			try {
				if(conn != null) {
					conn.rollback();  // 트렌잭션 취소
					System.out.println("[트랜잭션] 취소");
				}
			}
			catch(SQLException ce) {
				System.out.println("[예외발생] connection close failed. " + ce.getMessage());
			}
			throw new RuntimeException(e);
		} 
		finally {
			if (conn != null) {
				System.out.println("[트랜잭션] finally 시작");
				try {
					System.out.println("[트랜잭션] finally, conn.close");
					conn.close();
				} 
				catch (SQLException e) {
				}
			}
		}
		System.out.println("[작업종료]");
		
	}
	public void delete(Connection conn, Member member) throws SQLException {
		String sql = String.format("DELETE FROM member WHERE email='%s'", member.getEmail());
		
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
		}
		catch(SQLException e) {
			throw new SQLException();
		}
	}
	
	public void update(Connection conn, Member member) throws SQLException{
		String sql = String.format("UPDATE member SET name=?, password=? WHERE email=?");
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			
			stmt.setLong(1, member.getId());
			stmt.setString(2, member.getPassword());
			stmt.setString(3, member.getName());
			stmt.setString(4, member.getEmail());
			stmt.executeUpdate();
		}
		catch(SQLException e) {
			throw new SQLException();
		}
		finally {
			try {
				if(stmt != null) {
					stmt.close();
				}
			}
			catch(Exception se) {
				se.printStackTrace();
			}
		}
		
	}
	
	public void insert(Connection conn, Member member) throws SQLException{
		String sql = String.format("INSERT INTO member(id, name, email, password, regdate) VALUES (member_id_seq.nextval, ?, ?, ?, sysdate)");
		PreparedStatement stmt = null;
		
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, member.getName());
			stmt.setString(2, member.getEmail());
			stmt.setString(3, member.getPassword());
			stmt.executeUpdate();
		}
		catch(SQLException e) {
			System.out.println("[insert] Exception:" + e.getMessage());
			throw new SQLException();
		}
		finally {
			try {
				if(stmt != null) {
					stmt.close();
				}
			}
			catch(Exception se) {
				se.printStackTrace();
			}
		}
		
	}
	
}
