package spring.exceptions;

public class MemberNotFoundException extends RuntimeException {

}
