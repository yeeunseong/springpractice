package spring.exceptions;

public class WrongIdPasswordException extends RuntimeException {

}
