/*
 * 전통적인 JDBC 처리 모듈
 * DataSource는 tomcat의 커넥션 풀을 사용
 */
package spring.service;



import org.springframework.transaction.annotation.Transactional;

import spring.dao.Member;
import spring.dao.MemberDao;

public class TransactionalTestService {
	private MemberDao memberDao;

	public TransactionalTestService(MemberDao memberDao) {
		this.memberDao = memberDao;
	}
	
	@Transactional
	public void transactionOne(Member member) {
		System.out.println("[트랜잭션] 시작");
		
		System.out.println("[트랜잭션] 입력");
		this.memberDao.insert(member);
		System.out.println("입력데이터: " + member);
		
		System.out.println("[트랜잭션] 수정");
		this.memberDao.update(member);
		
		System.out.println("[트랜잭션] 삭제");
		this.memberDao.delete(member.getId());
		
		System.out.println("[트랜잭션] 종료");
		
	}

	
		
	
	
	
	
}
